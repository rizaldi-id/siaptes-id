<?php
// login.php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($email) && !empty($password)) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_avatar'] = $user['avatar'] ?? null;

            if ($user['role'] === 'admin') {
                header('Location: admin/index.php');
            } else {
                header('Location: index.php?msg=Selamat datang kembali, ' . urlencode($user['name']) . '!');
            }
            exit;
        } elseif ($user && !empty($user['google_id'])) {
            $error = 'Email ini terdaftar melalui Google. Silakan klik tombol "Masuk dengan Akun Google" di atas, atau daftar ulang di menu Daftar Akun dengan email ini untuk mengatur kata sandi manual.';
        } else {
            $error = 'Email atau kata sandi tidak cocok.';
        }
    } else {
        $error = 'Harap isi seluruh formulir.';
    }
}

$page_title = "Masuk Akun";
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 480px; margin: 3rem auto;">
    <div class="card card-navy-top" style="padding: 2.25rem;">
        <div style="text-align: center; margin-bottom: 1.75rem;">
            <div style="display: inline-flex; align-items: center; justify-content: center; width: 56px; height: 56px; border-radius: var(--radius-sm); background: linear-gradient(135deg, var(--core-navy) 0%, #073b64 100%); color: var(--core-gold); margin-bottom: 0.85rem; box-shadow: 0 4px 10px rgba(0, 43, 73, 0.25);">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                </svg>
            </div>
            <h2 style="font-size: 1.45rem; font-weight: 800; color: var(--core-navy); margin-bottom: 0.25rem;">Masuk ke SIAP TES</h2>
            <p style="color: var(--core-text-muted); font-size: 0.85rem;">
                Satu Akun untuk Semua Tryout CPNS, BUMN, Kedinasan & Psikotes di <b>siaptes.id</b>
            </p>
        </div>

        <a href="google-login.php" style="display: flex; align-items: center; justify-content: center; gap: 10px; width: 100%; padding: 0.75rem 1rem; background: #ffffff; border: 1.5px solid var(--core-border); border-radius: var(--radius-sm); color: var(--core-navy); font-weight: 700; font-size: 0.925rem; text-decoration: none; transition: all 0.2s; box-shadow: var(--shadow-sm);">
            <svg width="20" height="20" viewBox="0 0 24 24">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" fill="#EA4335"/>
            </svg>
            Masuk dengan Akun Google
        </a>

        <div style="display: flex; align-items: center; margin: 1.25rem 0; color: var(--core-text-dim); font-size: 0.78rem;">
            <div style="flex: 1; height: 1px; background: var(--core-border);"></div>
            <span style="padding: 0 0.75rem; text-transform: uppercase; font-weight: 700;">atau masukkan id kredensial</span>
            <div style="flex: 1; height: 1px; background: var(--core-border);"></div>
        </div>

        <?php if ($error): ?>
            <div style="background: var(--core-danger-light); color: var(--core-danger); padding: 0.75rem 1rem; border-radius: var(--radius-sm); margin-bottom: 1rem; font-size: 0.85rem; font-weight: 600; border-left: 4px solid var(--core-danger);">
                ⚠️ <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>ID Pengguna / Email Terdaftar</label>
                <input type="email" name="email" class="form-control" placeholder="nama@email.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Kata Sandi Akun</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 0.5rem; padding: 0.75rem;">
                Masuk ke Portal CAT ➔
            </button>
        </form>

        <div style="margin-top: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--core-border); text-align: center; font-size: 0.85rem; color: var(--core-text-muted);">
            Belum memiliki akun peserta? <a href="register.php" style="font-weight: 700; color: var(--core-navy);">Daftar Akun Baru</a>
        </div>
    </div>

    <!-- Info Demo Login Coretax Style -->
    <div style="background: #ffffff; border: 1px solid var(--core-border); padding: 1rem 1.25rem; border-radius: var(--radius-sm); font-size: 0.825rem; color: var(--core-text-muted); box-shadow: var(--shadow-sm);">
        <p style="font-weight: 700; color: var(--core-navy); margin-bottom: 0.35rem; display: flex; align-items: center; gap: 6px;">
            <span style="color: var(--core-gold);">●</span> Akun Demo Login Biasa (Tanpa Google):
        </p>
        <p style="margin-bottom: 0.2rem;">&bull; <b>Administrator:</b> <code>admin@cpns.go.id</code> / Sandi: <code>admin123</code></p>
        <p>&bull; <b>Peserta PRO VIP:</b> <code>peserta@cpns.go.id</code> / Sandi: <code>peserta123</code></p>
    </div>
    
    <div style="text-align: center; margin-top: 1rem; font-size: 0.75rem; color: var(--core-text-dim);">
        🔒 Dilindungi Sistem Enkripsi 256-Bit Standar Keamanan BKN
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
