<?php
// upgrade.php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

requireLogin();
$db = getDB();
$user = currentUser();
$isUserPremium = isPremiumUser();

$package_id = isset($_GET['package_id']) ? intval($_GET['package_id']) : 0;
$selectedPackage = null;
if ($package_id > 0) {
    $selectedPackage = $db->query("SELECT * FROM packages WHERE id = $package_id AND is_active = 1")->fetch();
}

$successMsg = '';
$errorMsg = '';

// Handle Checkout / Payment Confirmation
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $payment_method = trim($_POST['payment_method'] ?? 'QRIS Instant');
    $pkg_id = !empty($_POST['package_id']) ? intval($_POST['package_id']) : null;
    $amount = intval($_POST['amount'] ?? 49000);
    $notes = trim($_POST['notes'] ?? '');

    // Generate unique invoice number, e.g., INV-SIAPTES-20261014-ABCD
    $invNumber = 'INV-ST-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));

    $stmt = $db->prepare("
        INSERT INTO transactions (invoice_number, user_id, package_id, type, amount, payment_method, status, notes)
        VALUES (?, ?, ?, 'lifetime_premium', ?, ?, 'approved', ?)
    ");
    $stmt->execute([$invNumber, $user['id'], $pkg_id, $amount, $payment_method, $notes]);

    // Activate premium for this user!
    $db->prepare("UPDATE users SET is_premium = 1 WHERE id = ?")->execute([$user['id']]);

    header("Location: upgrade.php?success=1&invoice=" . urlencode($invNumber));
    exit;
}

if (isset($_GET['success'])) {
    $successMsg = "Pembayaran Berhasil! Akun Anda kini resmi berstatus PRO VIP All-Access. Seluruh modul tryout CPNS, BUMN, Kedinasan, dan Psikotes di siaptes.id telah terbuka penuh seumur hidup.";
}

$page_title = "Aktivasi Akses Penuh PRO VIP - SIAP TES";
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width: 900px; margin: 0 auto;">
    <div style="text-align: center; margin-bottom: 2.5rem;">
        <div style="display: inline-flex; align-items: center; gap: 6px; margin-bottom: 0.5rem;">
            <span class="badge badge-gold" style="font-size: 0.8rem; padding: 0.35rem 0.85rem;">
                ⭐ ALL-ACCESS PASS SEUMUR HIDUP &bull; SIAPTES.ID
            </span>
        </div>
        <h1 style="font-size: 2.15rem; font-weight: 800; color: var(--core-navy); margin-top: 0.25rem; margin-bottom: 0.5rem;">
            Aktivasi Akses Penuh Semua Tryout & Bank Soal
        </h1>
        <p style="color: var(--core-text-muted); font-size: 1rem; max-width: 680px; margin: 0 auto;">
            Satu akun untuk membuka <b>seluruh modul ujian</b>: CPNS (SKD 110 Soal), Rekrutmen Bersama BUMN, Sekolah Kedinasan (STAN/STIS/IPDN), dan Psikotes Kerja Asesmen Perusahaan.
        </p>
    </div>

    <?php if ($successMsg): ?>
        <div class="gov-notice" style="border-left-color: var(--core-success); background: #f0fdf4; margin-bottom: 2rem;">
            <div class="gov-notice-icon" style="background: var(--core-success-light); color: var(--core-success);">✓</div>
            <div class="gov-notice-content">
                <h4 style="color: var(--core-success); font-size: 1.1rem;">Aktivasi Lisensi PRO VIP Berhasil!</h4>
                <p style="color: #14532d; margin-bottom: 0.75rem;">
                    <?= htmlspecialchars($successMsg) ?><br>
                    Nomor Bukti Transaksi: <b><?= htmlspecialchars($_GET['invoice'] ?? 'INV-ST-OK') ?></b>
                </p>
                <a href="tryout.php" class="btn btn-primary btn-sm">
                    🚀 Masuk ke Halaman Simulasi Tryout Sekarang
                </a>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($isUserPremium && empty($successMsg)): ?>
        <div class="card card-navy-top" style="text-align: center; padding: 1.75rem; margin-bottom: 2rem;">
            <span style="font-size: 2.5rem;">👑</span>
            <h3 style="color: var(--core-navy); font-size: 1.25rem; font-weight: 800; margin-top: 0.5rem; margin-bottom: 0.25rem;">
                Status Akun: Member PRO VIP All-Access Aktif
            </h3>
            <p style="color: var(--core-text-muted); font-size: 0.9rem; margin-bottom: 1rem;">
                Anda telah memiliki hak akses tanpa batas ke seluruh paket tryout CPNS, BUMN, Kedinasan, Psikotes, kunci jawaban, dan pembahasan materi di siaptes.id.
            </p>
            <a href="tryout.php" class="btn btn-primary btn-sm">Jelajahi Tryout ➔</a>
        </div>
    <?php endif; ?>

    <!-- Perbandingan Fitur: Akun Gratis vs Akun PRO VIP -->
    <div class="card card-gold-top" style="margin-bottom: 2.5rem; padding: 2rem;">
        <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--core-navy); margin-bottom: 1.25rem; text-align: center;">
            Perbandingan Hak Akses: Akun Trial vs PRO VIP
        </h3>

        <div style="overflow-x: auto;">
            <table class="table" style="font-size: 0.95rem;">
                <thead>
                    <tr>
                        <th style="width: 45%;">Fitur Platform SIAP TES</th>
                        <th style="width: 25%; text-align: center;">Akun Trial (Gratis)</th>
                        <th style="width: 30%; text-align: center; background: #fef3c7; color: #b45309; font-weight: 800;">
                            ⭐ PRO VIP Member
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><b>Akses Simulasi Tryout CAT</b></td>
                        <td style="text-align: center; color: var(--core-text-muted);">Hanya Paket Mini Trial (30 Soal)</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            Semua Paket Tryout Terbuka (Full)
                        </td>
                    </tr>
                    <tr>
                        <td><b>Cakupan Jalur Seleksi</b></td>
                        <td style="text-align: center; color: var(--core-text-muted);">Pratinjau Terbatas</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            CPNS, BUMN, Kedinasan & Psikotes
                        </td>
                    </tr>
                    <tr>
                        <td><b>Tryout Akbar SKD 110 Butir (100 Menit)</b></td>
                        <td style="text-align: center; color: #dc2626;">✖ Terkunci</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            ✔ Bebas Diakses Kapan Saja
                        </td>
                    </tr>
                    <tr>
                        <td><b>Tryout RBB BUMN (TKD + AKHLAK + English)</b></td>
                        <td style="text-align: center; color: #dc2626;">✖ Terkunci</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            ✔ Bebas Diakses Kapan Saja
                        </td>
                    </tr>
                    <tr>
                        <td><b>Tryout Sekolah Kedinasan (STAN, STIS, IPDN)</b></td>
                        <td style="text-align: center; color: #dc2626;">✖ Terkunci</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            ✔ Bebas Diakses Kapan Saja
                        </td>
                    </tr>
                    <tr>
                        <td><b>Simulasi Psikotes Kerja & Asesmen</b></td>
                        <td style="text-align: center; color: #dc2626;">✖ Terkunci</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            ✔ Bebas Diakses Kapan Saja
                        </td>
                    </tr>
                    <tr>
                        <td><b>Kunci & Pembahasan Trik Cepat</b></td>
                        <td style="text-align: center; color: var(--core-text-muted);">Sebagian Kecil</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            Full Pembahasan & Konsep Dasar
                        </td>
                    </tr>
                    <tr>
                        <td><b>Masa Aktif Lisensi</b></td>
                        <td style="text-align: center; color: var(--core-text-muted);">Permanen</td>
                        <td style="text-align: center; font-weight: 700; color: #047857; background: #fffbeb;">
                            Seumur Hidup (Sekali Bayar, Tanpa Iuran)
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Kotak Form Pembayaran -->
    <?php if (!$isUserPremium): ?>
        <div class="grid-2" style="align-items: start;">
            <!-- Rincian Harga & Promo -->
            <div class="card card-gold-top">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                    <span class="badge" style="background: var(--core-danger-light); color: var(--core-danger); font-weight: 800;">PROMO SPESIAL 65%</span>
                    <span style="font-size: 0.8rem; color: var(--core-text-muted);">siaptes.id All-Access</span>
                </div>

                <h3 style="font-size: 1.35rem; font-weight: 800; color: var(--core-navy); margin-bottom: 0.5rem;">
                    Akses Penuh PRO VIP Seumur Hidup
                </h3>
                <p style="font-size: 0.875rem; color: var(--core-text-muted); margin-bottom: 1.25rem;">
                    Buka seluruh simulasi CAT, ratusan bank soal lintas kategori, evaluasi passing grade, dan trik pembahasan cepat.
                </p>

                <div style="margin-bottom: 1.5rem; background: var(--core-navy-subtle); padding: 1.15rem; border-radius: var(--radius-sm); border: 1px solid var(--core-border);">
                    <div style="font-size: 0.85rem; color: var(--core-text-muted); text-decoration: line-through;">Rp 149.000</div>
                    <div style="display: flex; align-items: baseline; gap: 0.5rem;">
                        <span style="font-size: 2.25rem; font-weight: 800; color: var(--core-navy);">Rp 49.000</span>
                        <span style="font-size: 0.85rem; color: var(--core-text-muted);">/ sekali bayar</span>
                    </div>
                    <span style="font-size: 0.8rem; color: var(--core-success); font-weight: 700;">⚡ Sekali aktivasi, nikmati akses semua modul ujian selamanya tanpa biaya langganan bulanan</span>
                </div>

                <div style="font-size: 0.875rem; color: var(--core-text); line-height: 1.9;">
                    <div>🏛️ <b>CPNS / ASN:</b> Tryout Akbar SKD 110 Butir Berstandar BKN</div>
                    <div>🏢 <b>BUMN:</b> Simulasi TKD, Core Values AKHLAK & Bahasa Inggris</div>
                    <div>🎓 <b>Kedinasan:</b> Modul Khusus STAN, STIS, IPDN & Poltekip</div>
                    <div>🧠 <b>Psikotes:</b> Latihan Penalaran Logika, Spasial & SJT</div>
                    <div>📱 <b>Multi-Perangkat:</b> Akses lancar di Smartphone & Laptop</div>
                </div>
            </div>

            <!-- Form Checkout Instan -->
            <div class="card card-navy-top">
                <h3 style="font-size: 1.25rem; font-weight: 800; color: var(--core-navy); margin-bottom: 1rem;">
                    Konfirmasi Aktivasi PRO VIP
                </h3>

                <form method="POST" action="">
                    <input type="hidden" name="package_id" value="<?= $package_id ?>">
                    <input type="hidden" name="amount" value="49000">

                    <div class="form-group">
                        <label>Nama Peserta Terdaftar</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" readonly style="background: var(--core-bg);">
                    </div>

                    <div class="form-group">
                        <label>Email Akun SIAP TES</label>
                        <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly style="background: var(--core-bg);">
                    </div>

                    <div class="form-group">
                        <label>Pilihan Saluran Pembayaran *</label>
                        <select name="payment_method" class="form-control" required>
                            <option value="QRIS Instant (GoPay, OVO, Dana, ShopeePay, BCA Mobile)">QRIS Instant (Semua Bank & E-Wallet Nasional)</option>
                            <option value="Transfer Bank BCA (Virtual Account)">BCA Virtual Account (Otomatis)</option>
                            <option value="Transfer Bank Mandiri (Livin)">Mandiri Virtual Account</option>
                            <option value="Transfer Bank BRI (BRIVA)">BRI Virtual Account (BRIVA)</option>
                            <option value="Transfer Bank BNI (Mobile Banking)">BNI Virtual Account</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Kode Voucher / Catatan (Opsional)</label>
                        <input type="text" name="notes" class="form-control" placeholder="Contoh: SIAPTES2026">
                    </div>

                    <div style="background: #ffffff; border: 1px dashed var(--core-border); padding: 0.85rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem; font-size: 0.8rem; color: var(--core-text-muted);">
                        ℹ️ <b>Aktivasi Otomatis:</b> Akun Anda langsung aktif seketika menjadi PRO VIP begitu transaksi diproses tanpa perlu upload bukti manual.
                    </div>

                    <button type="submit" class="btn btn-gold" style="width: 100%; font-size: 1.05rem; padding: 0.85rem;">
                        💳 Proses Aktivasi Rp 49.000 ➔
                    </button>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
